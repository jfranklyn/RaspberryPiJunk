check user guide.
