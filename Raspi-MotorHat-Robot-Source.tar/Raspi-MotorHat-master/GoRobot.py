#!/usr/bin/python
#from evdev import InputDevice 
from Raspi_MotorHAT import Raspi_MotorHAT

import atexit
import time
import RPi.GPIO as GPIO
import sys
import Tkinter as tk

def init():
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BOARD)
    # set pins for distance sensor
    PIN_TRIGGER = 12
    PIN_ECHO = 18
    GPIO.setup(PIN_TRIGGER, GPIO.OUT)
    GPIO.setup(PIN_ECHO, GPIO.IN)
    GPIO.output(PIN_TRIGGER, GPIO.LOW)
    # max speed 255
    mh.getMotor(1).setSpeed(200)
    mh.getMotor(2).setSpeed(200)
    #mh.getMotor(3).setSpeed(50)
    #mh.getMotor(4).setSpeed(50)

# Triggering on keyboard events from arrow keys
#dev = InputDevice('/dev/input/event3') 
#print(dev)
mh = Raspi_MotorHAT(addr=0x6f)

def stop():
    mh.getMotor(1).run(Raspi_MotorHAT.RELEASE)
    mh.getMotor(2).run(Raspi_MotorHAT.RELEASE)
#    mh.getMotor(3).run(Raspi_MotorHAT.RELEASE)
#    mh.getMotor(4).run(Raspi_MotorHAT.RELEASE)
    GPIO.cleanup()

atexit.register(stop)

def forward(tf):
    init()
    mh.getMotor(1).run(Raspi_MotorHAT.FORWARD)
    mh.getMotor(2).run(Raspi_MotorHAT.FORWARD)
    time.sleep(tf)
    GPIO.cleanup()    

def back(tf):
    init()
    mh.getMotor(1).run(Raspi_MotorHAT.BACKWARD)
    mh.getMotor(2).run(Raspi_MotorHAT.BACKWARD)
    time.sleep(tf)
    GPIO.cleanup()
    
def right(tf):
    mh.getMotor(1).run(Raspi_MotorHAT.FORWARD)
    mh.getMotor(2).run(Raspi_MotorHAT.BACKWARD)
    time.sleep(tf)
    GPIO.cleanup()       

def left(tf):
    mh.getMotor(1).run(Raspi_MotorHAT.BACKWARD)
    mh.getMotor(2).run(Raspi_MotorHAT.FORWARD)
    time.sleep(tf)
    GPIO.cleanup()
        
def pivot_left(tf):
# pivot won't work with only 2 wheels    
    time.sleep(tf)
    GPIO.cleanup()

def pivot_right(tf):
    time.sleep(tf)
    GPIO.cleanup()

# Use distance sensor to detect front distance from objects
def distance():
    GPIO.output(PIN_TRIGGER, GPIO.HIGH)
    time.sleep(0.00001)
    GPIO.output(PIN_TRIGGER, GPIO.LOW)

    while GPIO.input(PIN_ECHO)==0:
        pulse_start_time = time.time()
    while GPIO.input(PIN_ECHO)==1:
        pulse_end_time = time.time()

    pulse_duration = pulse_end_time - pulse_start_time
    distance = round(pulse_duration * 17150, 2)
    print ("Distance:",distance,"cm")
    return distance

def key_input(event):
    init()
    print ('Key:', event.char)
    sleep_time = 0.030
    if key_press.lower() == 'w':
        forward(sleep_time)
    elif key_press.lower() == 's':
        reverse(sleep_time)
    elif key_press.lower() == 'a':
        left(sleep_time)
    elif key_press.lower() == 'd':
        right(sleep_time)
    elif key_press.lower() == 'q':
        pivot_left(sleep_time)
    elif key_press.lower() == 'r':
        pivot_right(sleep_time)        
    else:
        pass

try:
    curDis = distance()
    print('Current distance is ', curDis)

    if curDis < 10:
        init()
        reverse(2)

    command = tk.Tk()
    command.bind('<KeyPress>', key_press)
    command.mainloop()
    

finally:
    stop()
    GPIO.cleanup()
