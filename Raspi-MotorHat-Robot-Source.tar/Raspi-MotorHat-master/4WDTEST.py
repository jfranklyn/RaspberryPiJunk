#!/usr/bin/python
from evdev import InputDevice 
from Raspi_MotorHAT import Raspi_MotorHAT

import atexit
import time
import RPi.GPIO as GPIO

GPIO.setwarnings(False)
GPIO.cleanup()
GPIO.setmode(GPIO.BOARD)
# set pins for distance sensor
PIN_TRIGGER = 12
PIN_ECHO = 18
GPIO.setup(PIN_TRIGGER, GPIO.OUT)
GPIO.setup(PIN_ECHO, GPIO.IN)

GPIO.output(PIN_TRIGGER, GPIO.LOW)

# Triggering on keyboard events from arrow keys
dev = InputDevice('/dev/input/event3') 
print(dev)
mh = Raspi_MotorHAT(addr=0x6f)

def stop():
    mh.getMotor(1).run(Raspi_MotorHAT.RELEASE)
    mh.getMotor(2).run(Raspi_MotorHAT.RELEASE)
#    mh.getMotor(3).run(Raspi_MotorHAT.RELEASE)
#    mh.getMotor(4).run(Raspi_MotorHAT.RELEASE)

atexit.register(stop)

# max speed 200
mh.getMotor(1).setSpeed(150)
mh.getMotor(2).setSpeed(150)
#mh.getMotor(3).setSpeed(50)
#mh.getMotor(4).setSpeed(50)
startSpeed = 150
currSpeed = startSpeed

def forward():
        mh.getMotor(1).run(Raspi_MotorHAT.FORWARD)
        mh.getMotor(2).run(Raspi_MotorHAT.FORWARD)

def back():
        mh.getMotor(1).run(Raspi_MotorHAT.BACKWARD)
        mh.getMotor(2).run(Raspi_MotorHAT.BACKWARD)

def right():
        # slow down for turns
        mh.getMotor(1).setSpeed(currSpeed-50)
        mh.getMotor(2).setSpeed(currSpeed-50)
        time.sleep(1)
        mh.getMotor(1).run(Raspi_MotorHAT.FORWARD)
        mh.getMotor(2).run(Raspi_MotorHAT.BACKWARD)
        time.sleep(1)        
        mh.getMotor(1).setSpeed(startSpeed)
        mh.getMotor(2).setSpeed(startSpeed)         

def left():
        # slow down for turns
        mh.getMotor(1).setSpeed(currSpeed-50)
        mh.getMotor(2).setSpeed(currSpeed-50)
        time.sleep(1)    
        mh.getMotor(1).run(Raspi_MotorHAT.BACKWARD)
        mh.getMotor(2).run(Raspi_MotorHAT.FORWARD)
        time.sleep(1)            
        mh.getMotor(1).setSpeed(startSpeed)
        mh.getMotor(2).setSpeed(startSpeed)
        
def faster(currSpeed):
        currSpeed =+ 25
        mh.getMotor(1).setSpeed(currSpeed)
        mh.getMotor(2).setSpeed(currSpeed)
def slower(currSpeed):
        currSpeed =- 25    
        mh.getMotor(1).setSpeed(currSpeed)
        mh.getMotor(2).setSpeed(currSpeed)

# Use distance sensor to detect front distance from objects
def checkDistance():
        GPIO.output(PIN_TRIGGER, GPIO.HIGH)
        time.sleep(0.00001)
        GPIO.output(PIN_TRIGGER, GPIO.LOW)

        while GPIO.input(PIN_ECHO)==0:
            pulse_start_time = time.time()
        while GPIO.input(PIN_ECHO)==1:
            pulse_end_time = time.time()

        pulse_duration = pulse_end_time - pulse_start_time
        distance = round(pulse_duration * 17150, 2)
        print ("Distance:",distance,"cm")
        return distance

try:
    while (True):
         for event in dev.read_loop():
            #if (checkDistance() <= 15):
                 #sstop();   
             
            # look for keyboard arrow keys
             if (event.code == 103 and event.value == 1):
                    print ("Forward")
                    #print(event.value)
                    forward();
                    time.sleep(0.5)
             elif (event.code == 108 and event.value == 1):
                    print  ("Back")
                    #print(event.value)
                    back();
                    time.sleep(0.5)
             elif (event.code == 106 and event.value == 1) :
                    print ("right")
                    #print(event.value)
                    right();
                    time.sleep(0.5)
             elif (event.code == 105 and event.value == 1) :
                    print ("left")
                    #print(event.value)
                    left();
                    time.sleep(0.5)
                # faster
             elif (event.code == 110 and event.value == 1) :
                    print ("faster")
                    #print(event.value)
                    faster(currSpeed)
                    time.sleep(0.5)
                #slower    
             elif (event.code == 111 and event.value == 1) :
                    print ("slower")
                    #print(event.value)
                    slower(currSpeed)
                    time.sleep(0.5)                
                # enter key
             elif (event.code == 28 and event.value == 1) :
                    print ("Stop")
                    stop();

finally:
    GPIO.cleanup()
