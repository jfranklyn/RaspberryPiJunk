#!/usr/bin/python
from evdev import InputDevice , categorize, ecodes
from select import select
from Raspi_MotorHAT import Raspi_MotorHAT, Raspi_DCMotor

import atexit
import time
import Robot

# Triggering on keyboard events from arrow keys
dev = InputDevice('/dev/input/event3') 
print(dev)
mh = Raspi_MotorHAT(addr=0x6f)

def stop():
    mh.getMotor(1).run(Raspi_MotorHAT.RELEASE)
    mh.getMotor(2).run(Raspi_MotorHAT.RELEASE)
 
atexit.register(stop)

mh.getMotor(1).setSpeed(175)
mh.getMotor(2).setSpeed(175)

startSpeed = 200
currSpeed = startSpeed

def forward():
        mh.getMotor(1).run(Raspi_MotorHAT.FORWARD)
        mh.getMotor(2).run(Raspi_MotorHAT.FORWARD)

def back():
        mh.getMotor(1).run(Raspi_MotorHAT.BACKWARD)
        mh.getMotor(2).run(Raspi_MotorHAT.BACKWARD)
  
def right():
    #slow down for turns    
        mh.getMotor(1).setSpeed(100)
        mh.getMotor(2).setSpeed(100)
        mh.getMotor(1).run(Raspi_MotorHAT.FORWARD)
        mh.getMotor(2).run(Raspi_MotorHAT.BACKWARD)

def left():
    #slow down for turns
        mh.getMotor(1).setSpeed(100)
        mh.getMotor(2).setSpeed(100)
        mh.getMotor(1).run(Raspi_MotorHAT.BACKWARD)
        mh.getMotor(2).run(Raspi_MotorHAT.FORWARD)

def faster():
        mh.getMotor(1).setSpeed(200)
        mh.getMotor(2).setSpeed(200)
def slower():
        mh.getMotor(1).setSpeed(75)
        mh.getMotor(2).setSpeed(75)        
        
while (True):

        for event in dev.read_loop():
            # look for keyboard arrow keys
            if (event.code == 103 and event.value == 1):
                print ("Forward")
                print(event.value)
                forward();
                time.sleep(0.5)
            elif (event.code == 108 and event.value == 1):
                print  ("Back")
                print(event.value)
                back();
                time.sleep(0.5)
            elif (event.code == 106 and event.value == 1) :
                print ("right")
                print(event.value)
                right();
                time.sleep(0.5)
            elif (event.code == 105 and event.value == 1) :
                print ("left")
                print(event.value)
                left();
                time.sleep(0.5)
            # faster
            elif (event.code == 110 and event.value == 1) :
                print ("faster")
                print(event.value)
                faster();
                time.sleep(0.5)
            #slower    
            elif (event.code == 111 and event.value == 1) :
                print ("slower")
                print(event.value)
                slower();
                time.sleep(0.5)                
            # enter key
            elif (event.code == 28 and event.value == 1) :
                print ("Stop")
                stop();

